<!DOCTYPE html>
<html>
<head>
	<title>Fixed Sidebar Example</title>
  
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<!-- Custom CSS -->
	<style>
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  width: 250px;
  height: 100%;
  background-color: green; /* darker shade of gray */
  color: #fff;
  padding: 5px;
  z-index: 5000;
  box-shadow: 2px 0px 10px rgba(0, 0, 0, 0.2); /* add box-shadow effect */
  font-family: 'Open Sans', sans-serif; /* add font-family */
  font-size: 16px; /* increase font size */
}

.sidebar ul {
  margin: 0;
  padding: 0;
  list-style: none;
}

.sidebar li {
  margin-bottom: 10px;
}

.sidebar a {
  display: block;
  padding: 10px;
  color: #fff;
  text-decoration: none;
  transition: all 0.3s ease; /* add animation effect */
}

.sidebar a:hover {
  background-color: #3e4166; /* lighter shade of gray on hover */
  color: #fff;
}

.sidebar .active a {
  background-color: #28a745;
  color: #fff;
  font-weight: bold;
  font-size: 20px; /* increase font size to 20 pixels */
}

.sidebar #logout-btn {
  position: absolute;
  bottom: 0px; /* add some padding */
  left: 0px;
  width: 250px;
  background-color: #dc3545; /* red */
  color: #fff;
  border: none;
  padding: 25px; /* add some padding */
  font-size: 16px;
  text-align: center;
  text-transform: uppercase;
  cursor: pointer;
  transition: all 0.3s ease;
}

.sidebar #logout-btn:hover {
  background-color: #c82333; /* darker red on hover */
}


	</style>
</head>
<body>
<nav class="sidebar">
  <ul class="list-unstyled">
    <li class="active">
      <a href="admin.php">Dashboard</a>
    </li>

    <li>
      <a href="users.php">Users</a>
    </li>
    <li>
      <a href="new_request.php">New Requests</a>
    </li>
    <li>
      <a href="approved_request.php">Approved Requests</a>
    </li>
   
    <li>
      
      <a href="..//logout.php" id="logout-btn">Logout</a>
  </ul>
</nav>


	<!-- Bootstrap JS -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
