<?php
include '..//connection.php';


if(isset($_POST['approve'])){
  $id=$_POST['id'];
  $select="UPDATE laundry_request SET `status`='1',`request_status`='1' WHERE id='$id'";
  $result=mysqli_query($conn, $select);
  echo '<script type=""text/javascript>';
  echo 'alert("request approved!");';
  echo 'window.location.href = "new_request.php"';
  echo '</script>';
  }
  if(isset($_POST['deny'])){
    $id=$_POST['id'];
    $select="UPDATE laundry_request SET `status`='2',`request_status`='3' WHERE id='$id'";
    $result=mysqli_query($conn, $select);
    echo '<script type=""text/javascript>';
    echo 'alert("user request Denied");';
    echo 'window.location.href = "new_request.php"';
    echo '</script>';
    } 
    
    
    
    
    
    ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Laundary request Form</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .content {
	padding-left: 250px;
}
    
/* Table */
.table {
  background-color: #f7f7f7;
  margin-top: 50px;
}

.table h1 {
  font-size: 36px;
  margin-bottom: 30px;
}

.table th {
  background-color: #4CAF50;
  color: #fff;
  font-size: 18px;
  padding: 15px;
}

.table td {
  font-size: 16px;
  padding: 10px 15px;
}

.table tr:nth-child(even) {
  background-color: #f2f2f2;
}

.table tr:hover {
  background-color: #e2e2e2;
}

/* Form */
form {
  display: inline-block;
}


    </style>

  </head>
  <body>
    <?php
    include 'admin_nav.php';
    ?>
   <div class="content">
  <div class=" mt-6">
  <div class="row justify-content-center">
    <div class="col-10 col-md-8 col-lg-6 text-center">
      <h1 class="mb-4">New Requests</h1>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-18">
      <table class="table table-striped">
        <thead class="thead-dark">
          <tr>
            <th>Name</th>
            <th>Number of Clothes</th>
            <th>Drop Date</th>
            <th>Pick-up Date</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $sql="SELECT * FROM `laundry_request` WHERE status='0'";
          $result=mysqli_query($conn,$sql);

          while($row=mysqli_fetch_array($result)){
          ?>
          <tr>
            <td class="border"><?php echo $row['name']; ?></td>
            <td class="border"><?php echo $row['clothes']; ?></td>
            <td class="border"><?php echo $row['drop_date']; ?></td>
            <td class="border"><?php echo $row['pick_up_date']; ?></td>
            <td class="border"><?php echo $row['contact']; ?></td>
            <td class="border"><?php echo $row['address']; ?></td>
            <form action="new_request.php" method="POST">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
              <td class="text-center">
                <button type="submit" name="approve" class="btn btn-success mr-3" style="background-color: #4CAF50; border-color: #4CAF50;">Approve</button>
                <button type="submit" name="deny" class="btn btn-danger " style="background-color: #D32F2F; border-color: #D32F2F;">Reject</button>
              </td>
            </form>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>



</div>
   
  </body>
</html>
