<?php
include '..//connection.php';


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $id = $_POST['id'];
    $status = $_POST['status'];
  
    $sql = "UPDATE `laundry_request` SET `request_status`='$status' WHERE `id`='$id'";
    $result = mysqli_query($conn, $sql);
  
    if($result){
      echo '<script type="text/javascript">';
      echo 'alert("Request status updated successfully");';
      echo 'window.location.href = "approved_request.php"';
      echo '</script>';
    }
    else{
      echo 'Error updating request status';
    }
  }
    
    
    
    
    ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Laundary request Form</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
     
    .content {
	padding-left: 250px;
}
  
  .container {
    max-width: 800px;
    margin: 0 auto;
  }
  
  .btn {
    font-weight: bold;
    color: white;
    text-transform: uppercase;
    padding: 10px 20px;
    border: none;
    transition: all 0.3s ease;
  }
  
  .btn-primary {
    background-color: #4CAF50;
    border-radius: 5px;
    border-color: #4CAF50;
  }
  
  .btn-primary:hover {
    background-color: #3E8E41;
    border-color: #3E8E41;
  }
  
  h1 {
    font-size: 36px;
    font-weight: bold;
    text-align: center;
    margin-bottom: 40px;
  }
  
  table {
    width: 100%;
    background-color: #f7f7f7;

    margin-bottom: 40px;
    border-collapse: collapse;
    border: 1px solid #ddd;
  }
  
  th, td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
  }
  
  th {
    background-color: #4CAF50;
    color: white;
    font-weight: bold;
  }
  
  tr:nth-child(even) {
    background-color: #f2f2f2;
  }
  
  select {
    width: 100%;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    padding: 10px;
    border: none;
    border-radius: 5px;
    transition: all 0.3s ease;
  }
  
  select:focus {
    outline: none;
    box-shadow: 0 0 5px #4CAF50;
  }
  
  option {
    font-weight: bold;
    text-transform: uppercase;
  }


    </style>

  </head>
  <body>
    <?php
include 'admin_nav.php';

?>
   
 <div class="content">

  <div class="container mt-4">

  <h1 class="text-center mb-4">Approved Requests</h1>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Name</th>
        <th>Number of Clothes</th>
        <th>Drop Date</th>
        <th>Pick-up Date</th>
        <th>Contact</th>
        <th>Address</th>
        <th>Request Status</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = "SELECT * FROM `laundry_request` WHERE status='1'";
      $result = mysqli_query($conn, $sql);
      while($row = mysqli_fetch_array($result)) {
      ?>
        <tr>
          <td><?php echo $row['name']; ?></td>
          <td><?php echo $row['clothes']; ?></td>
          <td><?php echo $row['drop_date']; ?></td>
          <td><?php echo $row['pick_up_date']; ?></td>
          <td><?php echo $row['contact']; ?></td>
          <td><?php echo $row['address']; ?></td>
          <form action="approved_request.php" method="POST">
            <td>
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <select name="status" class="form-select" onchange="this.form.submit()">
                <option value="0" <?php if($row['request_status'] == 0) echo 'selected'; ?>>Pending</option>
                <option value="1" <?php if($row['request_status'] == 1) echo 'selected'; ?>>Process</option>
                <option value="2" <?php if($row['request_status'] == 2) echo 'selected'; ?>>Complete</option>
              </select>
            </td>
          </form>
        </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</div>

</div>
  </body>
</html>
