<?php
session_start();
include '..//connection.php';
$user_id=$_SESSION['user_id'];
if(!isset($user_id))
{
    header("location: ..//index.php");
}

    
if(isset($_POST['reject'])){
  $id=$_POST['id'];
  $select="UPDATE register SET status= '2' WHERE id='$id'";
  $result=mysqli_query($conn, $select);
  echo '<script type=""text/javascript>';
  echo 'alert("user account rejected/block");';
  echo 'window.location.href = "users.php"';
  echo '</script>';
  } 
     
    
    
    
    
    ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="..//css/color.css">

    <title> USERS </title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style type="text/css">
 

  img{
      float: left;
      margin: 5px;
      width: 250px;
      height: 150px;
  }
  .content {
	padding-left: 250px;
}
</style>
  </head>
  <body>
  <div class="content">
    <?php
include 'admin_nav.php';


?>
<h1 class="bg-secondary  text-center p-3">AVAILABLE USERS</h1>

<table class="table  table-striped table-hover">
  <tr>

  <th class="border">USERNAME</th>
  <th class="border">EMAIL</th>
  <th class="border">CONTACT</th>

  <th class="border">UPDATE USER</th>


  <th class="border">DELETE USER</th>
  </tr>

<?php
$sql="SELECT * FROM `register` WHERE type='user'";
$result=mysqli_query($conn,$sql);

while($row=mysqli_fetch_array($result)){


?>


<tr>


<td class="border "><?php   echo $row['username'];   ?></td>
<td class="border"><?php   echo $row['email'];   ?></td>

<td class="border">Approve user</td>

<td class="border">
<button class="btn-primary btn w-50"> <a href="update_user.php?id=<?php echo $row['id']; ?>" class="text-white"> update </a>  </button>
</td>

<td class="border">
<button class="btn-danger btn w-50"> <a href="delete_user.php?id=<?php echo $row['id']; ?>" class="text-white"> Delete </a>  </button>

</td>





</tr>
<?php

}
   


  ?>


</table>
<a class="btn btn-danger" onclick="history.back()" role="button">back</a>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>