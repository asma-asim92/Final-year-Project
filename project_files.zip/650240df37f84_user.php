<?php
session_start();
error_reporting(0);
include "..//connection.php";

$user_id=$_SESSION['user_id'];
if(!isset($user_id))
{
    header("location: index.php");
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Welcome Page</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Custom CSS -->
	<style>
		body {
			padding-top: 50px;
			background-color: #f5f5f5;
		}
		.container {
            background-color: #fff;
			padding: 20px;
			border-radius: 10px;
			box-shadow: 0px 0px 5px 1px rgba(0,0,0,0.2);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.btn-logout {
  margin-top: 10px;
  align-self: center;
}
	</style>
</head>
<body>
<div class="container">
		<h1 style="text-align: left;">Welcome User</h1>
		<p style="text-align: left;">You have successfully logged in.</p>
		<a href="logout.php" class="btn btn-primary btn-logout">Logout</a>
	</div>
	<!-- Bootstrap JS -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>