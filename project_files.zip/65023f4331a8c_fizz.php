<?php
for ($i = 1; $i <= 50; $i++) {
    // Check if the number is a multiple of both 3 and 5
    if ($i % 3 == 0 && $i % 5 == 0) {
        echo "FizzBuzz";
    }
    // Check if the number is a multiple of 3
    elseif ($i % 3 == 0) {
        echo "Fizz";
    }
    // Check if the number is a multiple of 5
    elseif ($i % 5 == 0) {
        echo "Buzz";
    }
    // If none of the above conditions are met, print the number itself
    else {
        echo $i;
    }
    
    // Add a line break for better readability
    echo "<br>";
}
?>
