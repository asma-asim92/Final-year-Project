<?php
session_start();

include 'connection.php';
if(isset($_POST['register'])){


$username=$_POST['username'];

$password=$_POST['password'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);



$select="SELECT *FROM register WHERE email='$email' OR username='$username'";
$result=mysqli_query($conn,$select);
if(mysqli_num_rows($result)>0){

  echo '<script type=""text/javascript>';
  echo 'alert("change email !this eamil or email is already taken");';
  echo 'window.location.href = "register.php"';
  echo '</script>';


}
else{
$sql="INSERT INTO `register`(`id`, `username`, `email`, `password`, `contact`, `type`) VALUES (NULL,'$username','$email','$hashed_password','$contact','user')";
mysqli_query($conn,$sql);
  echo '<script type=""text/javascript>';
  echo 'alert("register successfully");';
  echo 'window.location.href = "index.php"';
  echo '</script>';
}
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login Page</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <!-- Custom CSS -->
  <style>
    body{
  background: linear-gradient(to right, pink, purple);
}
.form-container {
  background-color: #f5f5f5;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 80%; /* Adjust the width as needed */
  max-width: 400px; /* Add a maximum width for responsiveness */
  margin: 0 auto;
}

.form-group {
  margin-bottom: 15px;
}

.form-control {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 10px;
  width: 100%;
  transition: border-color 0.2s ease-in-out;
}

.form-control:focus {
  border-color: #007bff;
}

.btn-primary {
  background-color: #007bff;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  color: #fff;
  cursor: pointer;
  transition: background-color 0.2s ease-in-out;
  width: 100%; /* Make the button full width */
}

.btn-primary:hover {
  background-color: #0056b3;
}

.text-center {
  text-align: center;
}


  </style>
</head>
<body>
  


<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="form-container">
       
        <form action="register.php" method="POST">
         
          <div class="form-group">
            <label for="user-id">User Name:</label>
            <input type="text" class="form-control" id="user" name="username" placeholder="Enter your username" required>
          </div>
          <div class="form-group">
            <label for="user-id">Email:</label>
            <input type="email" class="form-control"  name="email" placeholder="Enter your email" required>
          </div>
          <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
          </div>
          <div class="form-group">
  <label for="user-id">Contact:</label>
  <input type="tel" class="form-control" id="phone" name="contact" placeholder="03XXXXXXXXX" required>
</div>
          <button type="submit" name="register" class="btn btn-success btn-block w-25 mx-auto">REGISTER</button>
        </form>
        <p class="text-center mt-4">Already registered? Click <a href="index.php">here</a> to Login.</p>
      </div>
    </div>
  </div>
</div>

<script>
  document.getElementById('phone').addEventListener('input', function () {
    var inputValue = this.value.replace(/\D/g, ''); // Removes non-digit characters
    if (inputValue.length > 11) {
      inputValue = inputValue.slice(0, 11); // Limits the input to 11 digits
    }
    this.value = inputValue;
  });
</script>








<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>  

</body>
</html>